// defining my types
export interface LoginParam {
    email: string,
    password : string
}

export interface SignupParams{
    email : string,
    firstname: string,
    lastname: string,
    phone : string,
    password : string,
}